var firebaseConfig = {
  apiKey: "AIzaSyCzTKtYIllusTeA2HRcvT5t6pu235lvKTU",
  authDomain: "aneh-rf-gd.firebaseapp.com",
  projectId: "aneh-rf-gd",
  storageBucket: "aneh-rf-gd.appspot.com",
  messagingSenderId: "326358134354",
  appId: "1:326358134354:web:2b011ab705be0e6602f98b",
  measurementId: "G-TW3M1HK22W"
};
 firebase.initializeApp(firebaseConfig);